/**
 * Created by chaika on 25.01.16.
 */

$(function(){
    //This code will execute when the page is ready
    var PizzaCart = require('./order/PizzaCart');
    var API = require("./API");

    PizzaCart.initialiseCart();

    function checkName() {
        var val = $("#name").val().trim();
        for (var i = 0; i < val.length; i++) {
            if (val.charAt(i).toUpperCase() === val.charAt(i).toLowerCase() && val.charAt(i) !== " ") {
                return false;
            }
        }
        if (val.length < 8)
            return false;
        return true;
    }

    function checkPhone() {
        var val = $("#phone_e").val().trim();
        for (var i = 0; i < val.length; i++) {
            if ((val.charAt(i) < "0" || val.charAt(i) > "9") && val.charAt(i) !== '+'){
                return false;
            }
        }

        if (val.length === 13) {
            if (val.substring(0, 4) !== "+380")
                return false;
            return true;
        }

        if (val.length === 10) {
            if (val.charAt(0) !== "0")
                return false;
            return true;
        }
        return false;
    }

    function checkAddress() {
        var val = $("#address").val().trim();
        if (val.length < 10)
            return false;
        return true;
    }

    $("#name").focusout(function() {
        if(checkName()) {
            $("#name_l").removeClass("error");
            $("#name").removeClass("error");
            $("#name_err").addClass("not_visible");
        }
        else {
            $("#name_l").addClass("error");
            $("#name").addClass("error");
            $("#name_err").removeClass("not_visible");
        }
    });
    $("#phone_e").focusout(function() {
        if (checkPhone()) {
            $("#phone_l").removeClass("error");
            $("#phone_e").removeClass("error");
            $("#phone_err").addClass("not_visible");
        }
        else {
            $("#phone_l").addClass("error");
            $("#phone_e").addClass("error");
            $("#phone_err").removeClass("not_visible");
        }
    });
    $("#address").focusout(function() {
        if(checkAddress()) {
            $("#address_l").removeClass("error");
            $("#address").removeClass("error");
            $("#address_err").addClass("not_visible");
        }
        else {
            $("#address_l").addClass("error");
            $("#address").addClass("error");
            $("#address_err").removeClass("not_visible");
        }
    });




    $("#order_button").click(function() {
        if (checkPhone() && checkName() && checkAddress()) {
            var order_info = {
                name: $("#name").val(),
                phone: $("#phone_e").val(),
                address: $("#address").val(),
                cart: PizzaCart.getPizzaInCart()
            };
            API.createOrder(order_info, function() {
                console.log("Order done");
            });
        }
    });
});