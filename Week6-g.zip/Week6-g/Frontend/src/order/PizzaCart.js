/**
 * Created by chaika on 02.02.16.
 */
var Templates = require("../Templates");
var Storage = require("../Storage");

//Перелік розмірів піци
var PizzaSize = {
    Big: "Велика",
    Small: "Мала"
};

//Змінна в якій зберігаються перелік піц в кошику
var Cart = [];

//HTML едемент куди будуть додаватися піци
var $cart = $("#order-body");
var $items_count = $("#items_count");
var $total_price = $("#price_val");

function initialiseCart() {
    var cart = Storage.get("cart");
    if (cart) Cart = cart;

    updateCart();
}

function getPizzaInCart() {
    //Повертає піци які зберігаються в кошику
    return Cart;
}

function updateCart() {
    //Функція викликається при зміні вмісту кошика
    //Тут можна наприклад показати оновлений кошик на екрані та зберегти вміт кошика в Local Storage

    Storage.set("cart", Cart);

    //Очищаємо старі піци в кошику
    $cart.html("");
    $items_count.text(Cart.length);

    var price = 0;
    
    Cart.forEach(function(item) {
        var pizza_size =
            item.size === "Велика"
                ? item.pizza.big_size
                : item.pizza.small_size;
        price += item.quantity * pizza_size.price;
    });
    $total_price.text(price + " грн.");

    //Онволення однієї піци
    function showOnePizzaInCart(cart_item) {
        var html_code = Templates.PizzaCart_OneItem_Order(cart_item);
        var $node = $(html_code);
        $cart.append($node);
    }

    Cart.forEach(function(item) {
        showOnePizzaInCart(item);
    });
}

exports.getPizzaInCart = getPizzaInCart;
exports.initialiseCart = initialiseCart;

exports.PizzaSize = PizzaSize;
